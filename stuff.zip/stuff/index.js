const express = require('express');
const app = express();
const server = app.listen(3000);
const io = require('socket.io')(server);
const players = {},
	shots = [];

app.use(express.static(`${__dirname}/public`));

function update (){
	shots.map((shot, index) => {
		shot.x += -10 * Math.cos(shot.a);
		shot.y += -10 * Math.sin(shot.a);

		if(shot.x > 600 || shot.x < 0 || shot.y > 600 || shot.y < 0){
			shots.splice(index, 1);
		}
	});

	io.emit('update', players, shots);
}
setInterval(update, 50);

io.on('connection', socket => {
	console.log('client connected');
	socket.on('update', data => {
		players[socket.id] = data.player;
		data.shots.map(shot => {
			shots.push(shot);
		})
	});
	socket.on('disconnect', () => {
		players[socket.id] = undefined;
	})
})
